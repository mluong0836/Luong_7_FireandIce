package luong_7_testing_dungeon;

import org.newdawn.slick.state.*;

import java.io.IOException;
import org.newdawn.slick.*;

import java.util.ArrayList;

import java.util.Iterator;

import java.util.logging.Level;

import java.util.logging.Logger;

import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;

import org.newdawn.slick.AppGameContainer;

import org.newdawn.slick.BasicGame;

import org.newdawn.slick.Font;

import org.newdawn.slick.GameContainer;

import org.newdawn.slick.Graphics;

import org.newdawn.slick.Image;

import org.newdawn.slick.Input;

import org.newdawn.slick.SlickException;

import org.newdawn.slick.SpriteSheet;

import org.newdawn.slick.TrueTypeFont;

import org.newdawn.slick.geom.Rectangle;

import org.newdawn.slick.geom.Shape;

import org.newdawn.slick.state.BasicGameState;

import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

import org.newdawn.slick.tiled.TiledMap;
import org.w3c.dom.css.Rect;

public class Leveltwo extends BasicGameState {

    public Item healthpotion, healthpotion1;
    public Item1 speedpotion, speedpotion1;
    public Orb magic8ball;
    public Itemwin antidote;
    public Blue bluekey; // class for bluekeys
    public Yellow yellowkey;//class for yellowkeys
    public Green greenkey;//class for greenkeys
    public Pink pinkkey; //class for pinkkeys
    public Finalitem lastitem;//last item last bluekey
    public Itemwin2 orbz;
    public Player player;
    
    public Blueblocked blockedblue;
    public Orangeblocked blockedorange;
    public Greenblocked blockedgreen;
    public Pinkblocked blockedpink;
    public Lastblocked finalblocked; 
    public Trapsbomb trappy;
    
    public boolean playeratt = false;
    public Ninja stormy, daniel, sword;

    public Enemy flava, flav, jackson;
    //first public enemy

    public ArrayList<Item> stuff = new ArrayList();
    
    public ArrayList<Blue> unlock1 = new ArrayList();
    public ArrayList<Yellow> unlock2 = new ArrayList();
    public ArrayList<Green> unlock3 = new ArrayList();
    public ArrayList<Pink> unlock4 = new ArrayList();
    public ArrayList<Finalitem> unlock5 = new ArrayList();

    public ArrayList<Blueblocked> checkblue = new ArrayList();
    public ArrayList<Orangeblocked> checkorange = new ArrayList();
    public ArrayList<Greenblocked> checkgreen = new ArrayList();
    public ArrayList<Pinkblocked> checkpink = new ArrayList();
    public ArrayList<Lastblocked> checkfinal = new ArrayList();

    public ArrayList<Item1> stuff1 = new ArrayList();

    public ArrayList<Itemwin> stuffwin = new ArrayList();
    public ArrayList<Itemwin2> stuffwin2 = new ArrayList();

    public ArrayList<Ninja> dojo = new ArrayList();

    public ArrayList<Enemy> bonez = new ArrayList();

    
    private boolean[][] hostiles;
    // to let the game know which direction the player moves
    
     boolean direction_right;
     boolean direction_left;
     boolean direction_up;
     boolean direction_down;
     
     public boolean checkingb = false;
     public boolean checkingo = false;
     public boolean checkingg = false;
     public boolean checkingpp = false;
     public boolean finaln = false;
  
    private static TiledMap grassMap;

    private static AppGameContainer app;

    private static Camera camera;

    public static int counter = 0;
    private static int timer = 0;
    public static int counterwin = 2;
    public static Music cool; //music class
    public static Sound cannon;//canon sound
    public static Sound Sword_drawn;// sword drawn
    public static Sound Sword_clash;// sword clash
    // Player stuff
    /*private Animation sprite, up, down, left, right, wait, attackfrom_right, attackfrom_left, attackfrom_up, 
                      attackfrom_down, hurt;*/

    /**
     *
     * The collision map indicating which tiles block movement - generated based
     *
     * on tile properties
     */
    // changed to match size of sprites & map
    private static final int SIZE = 32;

    // screen width and height won't change
    private static final int SCREEN_WIDTH = 1000;

    private static final int SCREEN_HEIGHT = 750;

    public Leveltwo(int xSize, int ySize) {

    }

    public void init(GameContainer gc, StateBasedGame sbg)
            throws SlickException {

        gc.setTargetFrameRate(60);

        gc.setShowFPS(false);
        
        cool = new Music("res/other_file_music.ogg");
        cannon = new Sound("res/canon.ogg");
        Sword_drawn = new Sound("res/Sword_draw.ogg");
        Sword_clash = new Sound("res/Sword_clash.ogg");
        cool.loop(1.0F, 2.0F);
        

		// *******************
        
        grassMap = new TiledMap("res/Luong_5_dungeon_home3.tmx");

        // Ongoing checks are useful
        //System.out.println("Tile map is this wide: " + grassMap.getWidth());

        camera = new Camera(gc, grassMap);
        player = new Player();

		// *********************************************************************************
        // Player stuff --- these things should probably be chunked into methods
        // and classes
        // *********************************************************************************
        SpriteSheet runningSS = new SpriteSheet(
                "res/player.png", 64, 64, 0);

		// System.out.println("Horizontal count: "
        // +runningSS.getHorizontalCount());
        // System.out.println("Vertical count: " +runningSS.getVerticalCount());
        


		

		// *****************************************************************
        // Obstacles etc.
        // build a collision map based on tile properties in the TileD map
        Blockedtwo.blocked2 = new boolean[grassMap.getWidth()][grassMap.getHeight()];

		// System.out.println("Map height:" + grassMap.getHeight());
        // System.out.println("Map width:" + grassMap.getWidth());
        // There can be more than 1 layer. You'll check whatever layer has the
        // obstacles.
        // You could also use this for planning traps, etc.
        // System.out.println("Number of tile layers: "
        // +grassMap.getLayerCount());
       // System.out.println("The grassmap is " + grassMap.getWidth() + "by "
               // + grassMap.getHeight());

        for (int xAxis = 0; xAxis < grassMap.getWidth(); xAxis++) {

            for (int yAxis = 0; yAxis < grassMap.getHeight(); yAxis++) {

				 //int tileID = grassMap.getTileId(xAxis, yAxis, 0);
                
                // Why was this changed?
                // It's a Different Layer.
                // You should read the TMX file. It's xml, i.e.,human-readable
                // for a reason
                int tileID = grassMap.getTileId(xAxis, yAxis, 2);

                String value = grassMap.getTileProperty(tileID,
                        "blocked", "false");

                if ("true".equals(value)) {

                    //System.out.println("The tile at x " + xAxis + " andy axis "
                            //+ yAxis + " is blocked.");

                    Blockedtwo.blocked2[xAxis][yAxis] = true;

                }

            }

        }
        //blocked properties
        Blockedtwo.blocked2[4][4] = true;
        //System.out.println("Array length" + Blocked.blocked[0].length);

        // A remarkably similar process for finding hostiles
        hostiles = new boolean[grassMap.getWidth()][grassMap.getHeight()];

        for (int xAxis = 0; xAxis < grassMap.getWidth(); xAxis++) {
            for (int yAxis = 0; yAxis < grassMap.getHeight(); yAxis++) {
                int xBlocktwo = (int) xAxis;
                int yBlocktwo = (int) yAxis;
                if (!Blockedtwo.blocked2[xBlocktwo][yBlocktwo]) {
                    if (yBlocktwo % 7 == 0 && xBlocktwo % 15 == 0) {
                        Item i = new Item(xAxis * SIZE, yAxis * SIZE);
                        Enemy e = new Enemy(xAxis * SIZE, yAxis * SIZE);
                        bonez.add(e);
                        //bonez.add(flava);
                        stuff.add(i);
                        //stuff1.add(h);
                        hostiles[xAxis][yAxis] = true;
                    }
                }
            }
        }

        
        for (int xAxis = 0; xAxis < grassMap.getWidth(); xAxis++) {
            for (int yAxis = 0; yAxis < grassMap.getHeight(); yAxis++) {
                int xBlocktwo = (int) xAxis;
                int yBlocktwo = (int) yAxis;
                if (!Blockedtwo.blocked2[xBlocktwo][yBlocktwo]) {
                    if (xBlocktwo % 9 == 0 && yBlocktwo % 25 == 0) {
                        Item1 h = new Item1(xAxis * SIZE, yAxis * SIZE);
                        //	stuff.add(i);
                        stuff1.add(h);
                        hostiles[xAxis][yAxis] = true;
                    }
                }
            }
        }
        
        
        healthpotion = new Item(100, 100);
        healthpotion1 = new Item(450, 400);
        stormy = new Ninja(0, 0);
        daniel = new Ninja(600, 254);
        sword = new Ninja(124, 254);
        dojo.add(stormy);
        dojo.add(daniel);
        dojo.add(sword);
      
        bluekey = new Blue(1495,252); //this is the blue key that will be visible when enemy dies
        yellowkey = new Yellow(1469, 770); //this is the yellow key that will be visible when enemy dies
        greenkey = new Green(160, 1206); //this is the green key that will be visible when enemy dies
        pinkkey = new Pink(1500, 1700); //this is the pink key that will be visible when enemy dies
        lastitem = new Finalitem(140, 2000); //this is the final blue key that will be visible when enemy dies
        unlock1.add(bluekey);
        unlock2.add(yellowkey);
        unlock3.add(greenkey);
        unlock4.add(pinkkey);
        unlock5.add(lastitem);
        
        trappy = new Trapsbomb(4,4);

        blockedblue = new Blueblocked(46,510);
        blockedorange = new Orangeblocked(1313, 1025);
        blockedgreen = new Greenblocked(50, 1480);
        blockedpink = new Pinkblocked(1376, 1877);
        finalblocked = new Lastblocked(1369, 2229);
        checkblue.add(blockedblue);
        checkorange.add(blockedorange);
        checkgreen.add(blockedgreen);
        checkpink.add(blockedpink);
        checkfinal.add(finalblocked);
        
        flava = new Enemy(300, 300);
        flav = new Enemy(256, 256);
        jackson = new Enemy(142, 142);
        bonez.add(flava);
        bonez.add(flav);
        //bonez.add(jackson);

        stuff.add(healthpotion);
        //stuff.add(healthpotion1);
        magic8ball = new Orb((int) Player.x + 5, (int) Player.y -10);//use int to make it accept float conversion
        //orb1 = new Orb(int) Player.x + 5, (int) Player.y - 5;

        speedpotion = new Item1(100, 150);
        speedpotion1 = new Item1(450, 100);
        stuff1.add(speedpotion);
        stuff1.add(speedpotion1);

        antidote = new Itemwin(800, 2800);
        orbz = new Itemwin2(2300,2600);
        //blade = new Itemwin(3000,34);
        stuffwin.add(antidote);
        stuffwin2.add(orbz);
        //stuffwin.add(blade);
    }

    public void render(GameContainer gc, StateBasedGame sbg, Graphics g)
            throws SlickException {

        camera.centerOn((int) Player.x, (int) Player.y);

        camera.drawMap();

        camera.translateGraphics();
        
        // it helps to add status reports to see what's going on
        // but it gets old quickly
        //System.out.println("Current X: " +Player.x + " \n Current Y: "+ Player.y);
        Image s5 = new Image("res/s5.png");
        Image s7 = new Image("res/s7.png");
        Image wall_right_light = new Image("res/0160_wall_right_light.bmp");
        Image wall_top_light = new Image("res/0159_wall_top_light.bmp");
        Image wall1_top_light = new Image("res/0158_wall_top_light.bmp");
        Image wall_left_bottom_corner = new Image("res/0157_wall_left_bottom_corner.bmp");
        Image wall_right_bottom_corner = new Image("res/0156_wall_right_bottom_corner.bmp");
        Image wall_left_corner = new Image("res/0155_wall_left_corner.bmp");
        Image wall_left_vert = new Image("res/0154_wall_left_vert.bmp");
        Image bottom_wall_horz = new Image("res/0153_bottom_wall_horz.bmp");
        Image wall_right_vert = new Image("res/0152_wall_right_vert.bmp");
        Image wall_right_corner = new Image("res/0151_wall_right_corner.bmp");
        Image wall_horz = new Image("res/0150_top_wall_horz.bmp");
        Image floor_default = new Image("res/0035_floor_default.bmp");
        Image floor1_default = new Image("res/0033_floor_default.bmp");
        Image floor2_default = new Image("res/0032_floor_default.bmp");
        Image floor0_default = new Image("res/0023_floor_default.bmp");
        Image floor3_default = new Image("res/0021_floor_default.bmp");
        Image reddpotion = new Image("res/red-potion.png");
        Image purplepotion = new Image("res/purple-potion.png");
        Image greenpotion = new Image("res/green-potion.png");
        Image bluepotion = new Image("res/blue-potion.png");
        Image blackpotion = new Image("res/black-potion.png");
        Image Luong_7_lava_entrance = new Image("res/Luong_7_lava_entrance.png");
        Image bombs = new Image("res/bombs.png");
        Image lava_boss = new Image("res/lava_boss.jpg");
        Image chest_item = new Image("res/chest_item.png");
        Image ice_castle = new Image("res/ice_castle.jpg");
        Image bridge = new Image("res/bridge.png");
        Image pokemon_ice_1 = new Image("res/pokemon_ice_1.png");
        Image pokemon_ice2 = new Image("res/pokemon_ice2.png");
       
 

        player.sprite.draw((int) Player.x, (int) Player.y);

        g.drawString("x: " + (int)player.x + "y: " +(int)player.y , player.x, player.y - 10);
       
        //g.drawString("Health: " + Player.health / 1000, camera.cameraX + 10,
               // camera.cameraY + 10);

       // g.drawString("speed: " + (int) (Player.speed * 10), camera.cameraX + 10,
                //camera.cameraY + 25);
        
        //g.drawString(Current X: " + Player.x + "  Current Y: "+ Player.y));
        //Current X: " +Player.x + " \n Current Y: "+ Player.y
        //g.drawString("Current X: " + Player.x , camera.cameraX + 10, camera.cameraY + 10);
        
       // g.drawString("Current Y: " + Player.y, camera.cameraX + 30, camera.cameraY + 30);
        //g.draw(player.rect);
       // g.drawString("time passed: " + counter / 1000, camera.cameraX + 600, camera.cameraY);
        // moveenemies();
        

        for(Blueblocked r : checkblue) {
            if(r.isvisible) {
                r.currentImage.draw(r.x, r.y);
            }
        }
        
        for(Orangeblocked y : checkorange) {
            if(y.isvisible) {
                y.currentImage.draw(y.x, y.y);
            }
        }
        
        for(Greenblocked gg : checkgreen) {
            if(gg.isvisible) {
                gg.currentImage.draw(gg.x, gg.y);
            }
        }
        
        for(Pinkblocked pp : checkpink) {
            if(pp.isvisible) {
                pp.currentImage.draw(pp.x, pp.y);
            }
        }
        
        for(Lastblocked ll : checkfinal) {
            if(ll.isvisible) {
                ll.currentImage.draw(ll.x, ll.y);
            }
        }
        
        for (Item i : stuff) {
            if (i.isvisible) {
                i.currentImage.draw(i.x, i.y);
                // draw the hitbox
                //g.draw(i.hitbox);

            }
        }

        for (Ninja n : dojo) {
            if (n.isvisible) {
                n.currentImage.draw(n.x, n.y);
                //draw the hitbox
                //g.draw(n.hitbox);

            }
        }

        //stormy.currentImage.draw(stormy.x, stormy.y);
        //daniel.currentImage.draw(daniel.x, daniel.y);
        for (Enemy e : bonez) {
            if (e.isalive) {
                e.currentanime.draw(e.Bx, e.By);
                e.move();
                
                //draw the hitbox
                //g.draw(e.rect);
            }

        }
        
     

        /*for (Enemy e : bonez) {

            if (Player.rect.intersects(e.rect)) {
                //System.out.println("yay");
                if (e.isalive) {

                    Player.health += 10000;
                    e.isalive = false;
                }

            }
        }*/

        for (Item1 h : stuff1) {
            if (h.isvisible) {
                h.currentImage.draw(h.x, h.y);
                // draw the hitbox
                //g.draw(h.hitbox);

            }
        }

        for (Itemwin w : stuffwin) {
            if (w.isvisible) {
                w.currentImage.draw(w.x, w.y);
                // draw the hitbox
                //g.draw(w.hitbox);

            }
        }
        
        for (Itemwin2 r : stuffwin2) {
            if (r.isvisible) {
                r.currentImage.draw(r.x, r.y);
                // draw the hitbox
                //g.draw(w.hitbox);

            }
        }
        
        for (Blue b : unlock1) { //stage1
            if (b.isvisible) {
                b.currentImage.draw(b.x, b.y);
                
                // draw the hitbox
                //g.draw(i.hitbox);

            }
        }
        
        for (Blue b : unlock1) {

            if (Player.rect.intersects(b.hitbox)) {
                //System.out.println("yay");
                if (b.isvisible) {
                    
                    Player.speed += .1f;
                    b.isvisible = false;
                    checkingb = true;
                    //Blocked.blocked[xAxis][yAxis] = true;
                }
            }
        }
        
        for (Yellow y : unlock2) { //stage1
            if (y.isvisible) {
                y.currentImage.draw(y.x, y.y);
                // draw the hitbox
                //g.draw(i.hitbox);

            }
        }
        
        for (Yellow y : unlock2) {

            if (Player.rect.intersects(y.hitbox)) {
                //System.out.println("yay");
                if (y.isvisible) {

                    Player.speed += .1f;
                    y.isvisible = false;
                    checkingo = true;
                }

            }
        }
        
         for (Green gr : unlock3) { //stage1
            if (gr.isvisible) {
                gr.currentImage.draw(gr.x, gr.y);
                // draw the hitbox
                //g.draw(i.hitbox);

            }
        }
        
        for (Green gr : unlock3) {
            
            if(Player.rect.intersects(gr.hitbox)) {
                if (gr.isvisible) {
                    
                    Player.speed += .1f;
                    gr.isvisible = false;
                    checkingg = true;
                }
            }
        }
        
        for (Pink dd : unlock4) { //stage1
            if (dd.isvisible) {
                dd.currentImage.draw(dd.x, dd.y);
                // draw the hitbox
                //g.draw(i.hitbox);

            }
        }
        
        for (Pink dd : unlock4) {
            
            if(Player.rect.intersects(dd.hitbox)) {
                checkingpp = true;
                if (dd.isvisible) {
                    
                    Player.speed += .1f;
                    dd.isvisible = false;
                    
                }
            }
        }
        
        for (Finalitem f : unlock5) { //stage1
            if (f.isvisible) {
                f.currentImage.draw(f.x, f.y);
                // draw the hitbox
                //g.draw(i.hitbox);

            }
        }
        
        for (Finalitem f : unlock5) {
            
            if(Player.rect.intersects(f.hitbox)) {
                finaln = true;
                if (f.isvisible) {
                    
                    Player.speed += .1f;
                    f.isvisible = false;
                    
                }
            }
        }
        
        if(magic8ball.isIsVisible()) {
            magic8ball.getOrb().draw(magic8ball.getLocationX(), magic8ball.getLocationY());

        }

    }

    private void moveenemies() throws SlickException {

        for (Enemy e : bonez) {

            e.setdirection();

            e.move();

        }
    }
    

    public void update(GameContainer gc, StateBasedGame sbg, int delta)
            throws SlickException {

        counter += delta;
        timer += delta;
        
        Input input = gc.getInput();

        float fdelta = delta * Player.speed;

        Player.setpdelta(fdelta);

        double rightlimit = (grassMap.getWidth() * SIZE) - (SIZE * 0.75);

        // System.out.println("Right limit: " + rightlimit);
        float projectedright = Player.x + fdelta + SIZE;

        boolean cangoright = projectedright < rightlimit;

        // there are two types of fixes. A kludge and a hack. This is a kludge.
        if (input.isKeyDown(Input.KEY_UP)) {

            player.sprite = player.up;
            
            player.setDirection(0);
            //my booleans to check the direction
            direction_right = false;
            direction_left = false;
            direction_up = true;
            direction_down = false;

            float fdsc = (float) (fdelta - (SIZE * .15));

            if (!(isBlocked(Player.x, Player.y - fdelta) || isBlocked((float) (Player.x + SIZE + 1.5), Player.y - fdelta))) {

                player.sprite.update(delta);

                // The lower the delta the slower the sprite will animate.
                Player.y -= fdelta;

            }

        } else if (input.isKeyDown(Input.KEY_DOWN)) {

            player.sprite = player.down;
            player.setDirection(2);
            //my booleans to check the direction
            direction_right = false;
            direction_left = false;
            direction_up = false;
            direction_down = true;

            if (!isBlocked(Player.x, Player.y + SIZE + fdelta)
                    || !isBlocked(Player.x + SIZE - 1, Player.y + SIZE + fdelta)) {

                player.sprite.update(delta);

                Player.y += fdelta;

            }

        } else if (input.isKeyDown(Input.KEY_LEFT)) {

            player.sprite = player.left;
            player.setDirection(3);
            //my booleans to check the direction
            direction_right = false;
            direction_left = true;
            direction_up = false;
            direction_down = false;

            if (!(isBlocked(Player.x - fdelta, Player.y) || isBlocked(Player.x
                    - fdelta, Player.y + SIZE - 1))) {

                player.sprite.update(delta);

                Player.x -= fdelta;

            }

        } else if (input.isKeyDown(Input.KEY_RIGHT)) {

            player.sprite = player.right;
            player.setDirection(1);
            //my booleans to check the direction
            direction_right = true;
            direction_left = false;
            direction_up = false;
            direction_down = false;

            // the boolean-kludge-implementation
            if (cangoright
                    && (!(isBlocked(Player.x + SIZE + fdelta,
                            Player.y) || isBlocked(Player.x + SIZE + fdelta, Player.y
                            + SIZE - 1)))) {

                player.sprite.update(delta);
                                                 
                Player.x += fdelta;

            } // else { System.out.println("Right limit reached: " +
            // rightlimit);}

        } else if (input.isKeyPressed(Input.KEY_SPACE)){
            magic8ball.setDirection(player.getDirection());
            magic8ball.settimer(100);
            magic8ball.getHitbox().setX(magic8ball.getLocationX() + 5);
            magic8ball.getHitbox().setY(magic8ball.getLocationY() + 5);
            magic8ball.setIsVisible(!magic8ball.isIsVisible());
            magic8ball.setLocationX((int) Player.x);
            magic8ball.setLocationY((int) Player.y);
            cannon.play(); //sound effects
            playeratt = true;
        }  
        
        
        else if (input.isKeyDown(Input.KEY_R)) {

            //sprite = attackfrom_down;
            
            Sword_drawn.play(); //sound effects to draw sword
            Sword_clash.play(); //sound effects to fight
            player.settimer_attack(100);
            
            if (direction_right) {
                
                if(player.gettimer_attack() > 0) {
                    player.sprite = player.attackfrom_right;
                    player.sprite.restart();
                } else {
                    player.sprite = player.right;
                }
                player.counting();
                
            } else if(direction_left) {
                
                if(player.gettimer_attack() > 0) {
                    player.sprite = player.attackfrom_left;
                    player.sprite.restart();
                } else {
                    player.sprite = player.left;
                }
                player.counting();
                
            }else if(direction_up) {
                
                if(player.gettimer_attack() > 0) {
                    player.sprite = player.attackfrom_up;
                    player.sprite.restart();
                } else {
                    player.sprite = player.up;
                }
                player.counting();
                      
            }else if(direction_down){
                
                if(player.gettimer_attack() > 0) {
                    player.sprite = player.attackfrom_down;
                    player.sprite.restart();
                } else {
                    player.sprite = player.down;
                }
                player.counting();
            }     

        }
        

        Player.rect.setLocation(Player.getplayershitboxX(),
                Player.getplayershitboxY());
        
        for (Enemy e : bonez) {

            if (Player.rect.intersects(e.rect) && input.isKeyDown(Input.KEY_R)) {
                
                //System.out.println("yay");
                if (e.isalive) {

                    Player.health += 10000;
                    e.isalive = false;
                }

            }
        }
        
        for (Enemy p : bonez) {
            if(magic8ball.hitbox.intersects(p.rect) && playeratt) {
                
                    player.health += 10000;
                    p.isalive = false;
                
            }
        }

        for (Item i : stuff) {

            if (Player.rect.intersects(i.hitbox)) {
                //System.out.println("yay");
                if (i.isvisible) {
                    
                    Player.health += 10000;
                    i.isvisible = false;
                }

            }
        }

        for (Ninja n : dojo) {

            if (Player.rect.intersects(n.hitbox)) {
                
                //System.out.println("yay");
                if (n.isvisible) {

                    Player.health += 10000;
                    n.isvisible = false;
                }

            }
        }

        for (Item1 h : stuff1) {

            if (Player.rect.intersects(h.hitbox)) {
                //System.out.println("yay");
                if (h.isvisible) {

                    Player.speed += .1f;
                    h.isvisible = false;
                }

            }
        }

        for (Itemwin w : stuffwin) {

            if (Player.rect.intersects(w.hitbox)) {
                //System.out.println("yay");
                if (w.isvisible) {
                    w.isvisible = false;
                    makevisible();
                    counterwin--;

                }

            }
        }
        
        for (Blueblocked t : checkblue) {
            if (Player.rect.intersects(t.hitbox) && !checkingb) {
                Player.getplayersY();
                Player.y -= 20;
                //System.out.println("yay");
                if (t.isvisible) {
                    t.isvisible = false;
                    makevisible();
                }
            }
        }
        
        for (Orangeblocked y : checkorange) {
            if(Player.rect.intersects(y.hitbox) && !checkingo) {
                Player.getplayersY();
                Player.y -= 20;
                if(y.isvisible) {
                    y.isvisible = false;
                    makevisible();
                }
            }
        }
        
        for (Greenblocked gg : checkgreen) {
            if(Player.rect.intersects(gg.hitbox) && !checkingg) {
                Player.getplayersY();
                Player.y -= 20;
                if (gg.isvisible) {
                    gg.isvisible = false;
                    makevisible();
                }
            } else {
                if (gg.isvisible) {
                    gg.isvisible = false;
                    makevisible();
                }
            }
        }
        
        for (Pinkblocked rr : checkpink) {
            if(Player.rect.intersects(rr.hitbox) && !checkingpp) {
                Player.getplayersY();
                Player.y -= 60;
                if (rr.isvisible) {
                    rr.isvisible = false;
                    makevisible();
                }
            } else {
                if(rr.isvisible) {
                    rr.isvisible = false;
                    makevisible();
                }
            }
        }
        
        for (Lastblocked nb : checkfinal) {
            if(Player.rect.intersects(nb.hitbox) && !finaln) {
                Player.getplayersY();
                Player.y -= 60;
                if (nb.isvisible) {
                    nb.isvisible = false;
                    makevisible();
                }
            }
        }
        
        for (Itemwin2 r2 : stuffwin2) {
            if (Player.rect.intersects(r2.hitbox)) {
                //System.out.println("yay");
                if (r2.isvisible) {
                    r2.isvisible = false;
                    makevisible();
                    counterwin--;
        }
            }
        }
        
 
        
        
        
        if (magic8ball.isIsVisible()) {
            if (magic8ball.gettimer() > 0) {
                if (magic8ball.getDirection() == 0) {
                    magic8ball.setLocationX((int) player.x);
                    magic8ball.setLocationY(magic8ball.getLocationY()- 5);
                } else if (magic8ball.getDirection() == 2) {
                    magic8ball.setLocationX((int) player.x);
                    magic8ball.setLocationY(magic8ball.getLocationY()+ 5);
                } else if (magic8ball.getDirection() == 3) {
                    magic8ball.setLocationX(magic8ball.getLocationX() - 5);
                    magic8ball.setLocationY(magic8ball.getLocationY());
                } else if (magic8ball.getDirection() == 1) {
                    magic8ball.setLocationX(magic8ball.getLocationX() + 5);
                    magic8ball.setLocationY(magic8ball.getLocationY());
                }
                magic8ball.hitbox.setX(magic8ball.getLocationX());
                magic8ball.hitbox.setY(magic8ball.getLocationY());
                magic8ball.countdown();
            } else {
                magic8ball.setIsVisible(false);
            }
        }
        

        
        Player.health -= counter/1000;
		if(Player.health <= 0){
			makevisible();
			sbg.enterState(2, new FadeOutTransition(Color.black), new FadeInTransition(Color.black));
		}
       
        
        if(Fireandice.counterwin == 0) {
            counterwin = 2;
            sbg.enterState(3, new FadeOutTransition(Color.black), new FadeInTransition(Color.black));
        }
    }
        
    public int getID() {

        return 6;

    }

    public void makevisible() {
        for (Item1 h : stuff1) {

            h.isvisible = true;
        }

        for (Item i : stuff) {

            i.isvisible = true;
        }
    }

    private boolean isBlocked(float tx, float ty) {

        int xBlocktwo = (int) tx / SIZE;

        int yBlocktwo = (int) ty / SIZE;

        return Blockedtwo.blocked2[xBlocktwo][yBlocktwo];

        // this could make a better kludge
    }
    
    private void dasf() {
            
}

}
