/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luong_7_testing_dungeon;

import org.newdawn.slick.Animation;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;

/**
 *
 * @author mluong
 */
public class Player {
    
        public static float x = 96f;

	public static float y = 228f;

	public static int health = 100000;
	
	public static float speed = .4f;

	static float hitboxX = x + 8f;

	static float hitboxY = y + 8f;

	private static int startX, startY, width = 30, height = 42;

	public static Shape rect = new Rectangle(getplayershitboxX(),
			getplayershitboxY(), width, height);

	public static float pdelta;
        
        private int timerattack = 0;

	//public static Animation playeranime;
        
        public boolean blue;
        
        public boolean yellow;
        
        public boolean green;
        
        public boolean pink;
        
        public boolean last;

	public static void setpdelta(float somenum) {

		pdelta = somenum;
	}
        
        private int direction;
        
        public Animation sprite, up, down, left, right, wait, attackfrom_right, attackfrom_left, attackfrom_up, 
                      attackfrom_down, hurt;
        
        public Player() throws SlickException {
        SpriteSheet runningSS = new SpriteSheet(
                "res/player.png", 64, 64, 0);
        up = new Animation();

        up.setAutoUpdate(true);

        up.addFrame(runningSS.getSprite(0, 1), 330);

        up.addFrame(runningSS.getSprite(1, 1), 330);

        up.addFrame(runningSS.getSprite(2, 1), 330);

        up.addFrame(runningSS.getSprite(3, 1), 330);

        up.addFrame(runningSS.getSprite(4, 8), 330);

        up.addFrame(runningSS.getSprite(5, 8), 330);

        up.addFrame(runningSS.getSprite(6, 8), 330);

        up.addFrame(runningSS.getSprite(7, 8), 330);

        up.addFrame(runningSS.getSprite(8, 8), 330);

        down = new Animation();

        down.setAutoUpdate(false);

        down.addFrame(runningSS.getSprite(0, 10), 330);

        down.addFrame(runningSS.getSprite(1, 10), 330);

        down.addFrame(runningSS.getSprite(2, 10), 330);

        down.addFrame(runningSS.getSprite(3, 10), 330);

        down.addFrame(runningSS.getSprite(4, 10), 330);

        down.addFrame(runningSS.getSprite(5, 10), 330);

        down.addFrame(runningSS.getSprite(6, 10), 330);

        down.addFrame(runningSS.getSprite(7, 10), 330);

        down.addFrame(runningSS.getSprite(8, 10), 330);

        left = new Animation();

        left.setAutoUpdate(false);

        left.addFrame(runningSS.getSprite(0, 9), 330);

        left.addFrame(runningSS.getSprite(1, 9), 330);

        left.addFrame(runningSS.getSprite(2, 9), 330);

        left.addFrame(runningSS.getSprite(3, 9), 330);

        left.addFrame(runningSS.getSprite(4, 9), 330);

        left.addFrame(runningSS.getSprite(5, 9), 330);

        left.addFrame(runningSS.getSprite(6, 9), 330);

        left.addFrame(runningSS.getSprite(7, 9), 330);

        left.addFrame(runningSS.getSprite(8, 9), 330);

        right = new Animation();

        right.setAutoUpdate(false);

        right.addFrame(runningSS.getSprite(0, 11), 330);

        right.addFrame(runningSS.getSprite(1, 11), 330);

        right.addFrame(runningSS.getSprite(2, 11), 330);

        right.addFrame(runningSS.getSprite(3, 11), 330);

        right.addFrame(runningSS.getSprite(4, 11), 330);

        right.addFrame(runningSS.getSprite(5, 11), 330);

        right.addFrame(runningSS.getSprite(6, 11), 330);

        right.addFrame(runningSS.getSprite(7, 11), 330);

        right.addFrame(runningSS.getSprite(8, 11), 330);

        wait = new Animation();

        wait.setAutoUpdate(true);

        wait.addFrame(runningSS.getSprite(0, 14), 733);

        wait.addFrame(runningSS.getSprite(1, 14), 733);

        wait.addFrame(runningSS.getSprite(2, 14), 733);

        wait.addFrame(runningSS.getSprite(3, 14), 733);
        
        // wait.addFrame(runningSS.getSprite(2, 14), 733);
        // wait.addFrame(runningSS.getSprite(5, 14), 333);
        
        sprite = wait;
        
        // sprite facing right
        attackfrom_right = new Animation();

        attackfrom_right.setAutoUpdate(true);
        
        
        attackfrom_right.addFrame(runningSS.getSprite(1, 31), 130);

        attackfrom_right.addFrame(runningSS.getSprite(4, 31), 130);

        attackfrom_right.addFrame(runningSS.getSprite(7, 31), 130);

        attackfrom_right.addFrame(runningSS.getSprite(10, 31), 130);
        
        attackfrom_right.addFrame(runningSS.getSprite(13, 31), 130);  
        
        attackfrom_right.addFrame(runningSS.getSprite(16, 31), 130); 
        
        attackfrom_right.addFrame(runningSS.getSprite(0, 11), 330);
   
        // sprite facing left
        attackfrom_left = new Animation();
        
        attackfrom_left.setAutoUpdate(true);

        attackfrom_left.addFrame(runningSS.getSprite(1, 25), 130);

        attackfrom_left.addFrame(runningSS.getSprite(4, 25), 130);

        attackfrom_left.addFrame(runningSS.getSprite(7, 25), 130);

        attackfrom_left.addFrame(runningSS.getSprite(10, 25), 130);
        
        attackfrom_left.addFrame(runningSS.getSprite(13, 25), 130);
        
        attackfrom_left.addFrame(runningSS.getSprite(16, 25), 130);
        
        attackfrom_left.addFrame(runningSS.getSprite(0, 9), 330);
        
        // sprite facing down
        attackfrom_down = new Animation();
        
        attackfrom_down.setAutoUpdate(true);

        attackfrom_down.addFrame(runningSS.getSprite(1, 28), 130);

        attackfrom_down.addFrame(runningSS.getSprite(4, 28), 130);

        attackfrom_down.addFrame(runningSS.getSprite(7, 28), 130);

        attackfrom_down.addFrame(runningSS.getSprite(10, 28), 130);
        
        attackfrom_down.addFrame(runningSS.getSprite(13, 28), 130);
        
        attackfrom_down.addFrame(runningSS.getSprite(16, 28), 130);
        
        attackfrom_down.addFrame(runningSS.getSprite(0, 10), 330);
        
        // sprite facing up
        attackfrom_up = new Animation();
        
        attackfrom_up.addFrame(runningSS.getSprite(1, 22), 130);

        attackfrom_up.addFrame(runningSS.getSprite(4, 22), 130);

        attackfrom_up.addFrame(runningSS.getSprite(7, 22), 130);

        attackfrom_up.addFrame(runningSS.getSprite(10, 22), 130);
        
        attackfrom_up.addFrame(runningSS.getSprite(13, 22), 130);  
        
        attackfrom_up.addFrame(runningSS.getSprite(16, 22), 130);
        
        attackfrom_up.addFrame(runningSS.getSprite(0, 1), 330);

        //when hurt
        hurt = new Animation();
        
        hurt.addFrame(runningSS.getSprite(0, 20), 230);

        hurt.addFrame(runningSS.getSprite(1, 20), 230);

        hurt.addFrame(runningSS.getSprite(2, 20), 230);
        
        hurt.addFrame(runningSS.getSprite(3, 20), 130);
        attackfrom_right.setLooping(false);
        attackfrom_right.restart();
        attackfrom_left.setLooping(false);
        attackfrom_left.restart();
        attackfrom_down.setLooping(false);
        attackfrom_down.restart();
        attackfrom_up.setLooping(false);
        attackfrom_up.restart();
        
        }

	public static float getpdelta() {

		return pdelta;

	}

	public static float getplayersX() {

		return x;

	}

	public static float getplayersY() {

		return y;

	}

	public static float getplayershitboxX() {

		return x + 18f;

	}

	public static float getplayershitboxY() {

		return y + 18f;

	}

	public static void setplayershitboxX() {

		hitboxX = getplayershitboxX();

	}

	public static void setplayershitboxY() {

		hitboxY = getplayershitboxY();

	}
        
        public void setDirection(int i){
        this.direction = i;
    }
        
    public int getDirection(){
        return this.direction;
    }

    
        public void stage1() {
            
            blue = true;
    
}
        public void stage2() {
            
            yellow = true;
        }
        
        public void stage3(){
    
            green = true;
}
        public void stage4() {
    
            green = true;
}
        
        public void stage5() {
            
            last = true;            
            
        }
        
        public void settimer_attack(int y){
            this.timerattack = y;
        }
        
        public int gettimer_attack() {
            
            return this.timerattack;
        }
        
        public void counting() {
            this.timerattack--;
        }
        
        
}
