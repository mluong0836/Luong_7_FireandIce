/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luong_7_testing_dungeon;

import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;

/**
 *
 * @author mluong
 */
public class Trapsbomb {
    public int x;
	public int y;
	public boolean isvisible = true; //false so enemy can be beaten
        public boolean enemy_alive;
	public Shape hitbox;
	public Image[] hi;
        
	Trapsbomb(int a, int b) throws SlickException {
		this.x = a;
		this.y = b;
		this.hitbox = new Rectangle(a, b, 256, 128);// 64 is the width of the item
		//this.hi[0] = new Image("res/bomb.png");
                //this.hi[1] = new Image("res/explosions.png");
                enemy_alive = true;
                
        }

  

}
